import streamlit as st
import pandas as pd
import qrcode
from io import BytesIO
import mysql.connector
import time
import os
from datetime import datetime

# Get database credentials from environment variables
mysql_user = os.getenv("MYSQL_USER")
mysql_password = os.getenv("MYSQL_PASSWORD")

def show(db):
    st.title("🏢 NGO Supply Management")
    
    # Authentication section
    
    # Get NGOs from database
    ngos = db.get_all_ngos()
    
    
    if ngos.empty:
        st.warning("⚠️ No NGOs found in the database.")
        return
    

    # Only show management interface if authenticated
    st.markdown(f"### Welcome, {ngos['name'].iloc[0]}")
    st.markdown("---")
    
    # Quick metrics in columns
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Items", "1,234", "5%")
    col2.metric("Pending Deliveries", "45", "-2")
    col3.metric("Centers Served", "12", "1")
    col4.metric("Success Rate", "98%", "0.5%")
    
    st.markdown("---")
    
    # Main tabs
    tab1, = st.tabs([
        "📦 Inventory Management",
    ])
    
    with tab1:
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.subheader("Current Inventory")
            conn = mysql.connector.connect(
                        host="localhost",
                        user=mysql_user,
                        password=mysql_password,
                        database="bantuannow",
                        port="3306"
                    )
            query = f"""
            SELECT * FROM ngo_inventory
            """
            items = pd.read_sql_query(query, conn)
            conn.close()
            
            st.dataframe(
                items,
                hide_index=True,
                use_container_width=True
            )


