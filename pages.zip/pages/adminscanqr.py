import cv2
from pyzbar.pyzbar import decode
import pandas as pd
import streamlit as st
import os
import time
import smtplib
import ssl
from datetime import datetime   
from email.message import EmailMessage
import mysql.connector
from mysql.connector import Error

# Get database credentials from environment variables
mysql_user = os.getenv("MYSQL_USER")
mysql_password = os.getenv("MYSQL_PASSWORD")

def send_alert_email(email, demand_id):
    """Send an email notification about a fulfilled demand."""
    try:
        email_sender = os.getenv('EMAIL_USER')
        email_password = os.getenv('EMAIL_PASSWORD')
        
        if not email_sender or not email_password:
            raise ValueError("Email credentials not found in environment variables")
        
        # Create the email message
        em = EmailMessage()
        em['From'] = email_sender
        em['To'] = email
        em['Subject'] = "Supply Demand Fulfilled Notification"
        
        email_content = f"""
        Dear Subscriber,
        
        Demand for the following item has been fulfilled:
        
        Demand ID: {demand_id}
        Status: Fulfilled
        
        Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        
        Best regards,
        Flood Monitoring Team
        """
        
        em.set_content(email_content)
        
        # Create SSL context
        context = ssl.create_default_context()
        
        # Send the email
        with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=context) as smtp:
            smtp.login(email_sender, email_password)
            smtp.sendmail(email_sender, email, em.as_string())
            
        return True
    except Exception as e:
        st.error(f"Failed to send email receipt: {str(e)}")
        return False

def get_db_connection():
    """Create and return a database connection."""
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user=mysql_user,
            password=mysql_password,
            database="bantuannow",
            port="3306"
        )
        return connection
    except Error as e:
        st.error(f"Database connection error: {e}")
        return None

def execute_query(query, params=None):
    """Execute a database query and return results."""
    connection = None
    cursor = None
    results = None
    
    try:
        connection = get_db_connection()
        if connection:
            cursor = connection.cursor(dictionary=True)
            cursor.execute(query, params or ())
            
            if cursor.with_rows:
                results = cursor.fetchall()
            else:
                connection.commit()
            
    except Error as e:
        st.error(f"Database error: {e}")
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()
    
    return results

def insert_qr_code(qr_type, qr_data):
    """Insert QR code data into the database."""
    query = "INSERT INTO qr_codes (qr_type, qr_data) VALUES (%s, %s)"
    execute_query(query, (qr_type, qr_data))
    return True

def update_demand_status(demand_id):
    """Update demand status to 'Fulfilled'."""
    query = "UPDATE supply_demands SET status='Fulfilled' WHERE demand_id = %s"
    execute_query(query, (demand_id,))
    return True

def get_email_subscribers():
    """Get list of email subscribers."""
    query = "SELECT email FROM email_list_for_alerts"
    results = execute_query(query)
    if results:
        return [row['email'] for row in results]
    return []

def list_cameras():
    """List available cameras."""
    index = 0
    arr = []
    while True:
        cap = cv2.VideoCapture(index)
        if not cap.read()[0]:
            break
        else:
            arr.append(index)
        cap.release()
        index += 1
    return arr

def show(db):
    """Main function to display the QR code scanner."""
    st.title("QR Code Scanner")
    
    # Camera selection
    available_cameras = list_cameras()
    if not available_cameras:
        st.error("No cameras detected on this device.")
        return
        
    selected_camera = st.selectbox("Select Camera", available_cameras)
    
    # Initialize camera
    cam = cv2.VideoCapture(selected_camera)
    cam.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    
    # Function to capture and process frames
    def capture_and_process_frame():
        success, frame = cam.read()
        if not success:
            return None, None
        qr_codes = decode(frame)
        return frame, qr_codes
    
    # Scanning control
    start_scanning = st.button("Start Scanning")
    
    if start_scanning:
        placeholder = st.empty()  # Placeholder for camera feed
        scanned_data = []  # Store scanned QR codes
        
        scanning = True
        scan_start_time = time.time()
        scan_duration = 60  # Scan for 60 seconds max
        
        # Main scanning loop
        while scanning:
            frame, qr_codes = capture_and_process_frame()
            if frame is None:
                st.error("Camera error. Please try again.")
                break
            
            # Display camera feed
            placeholder.image(frame, channels="BGR")
            
            # Process QR codes
            for qr_code in qr_codes:
                qr_data = qr_code.data.decode('utf-8')
                qr_type = qr_code.type
                
                # Display QR code info
                st.write(f"QR Code Type: {qr_type}")
                st.write(f"QR Code Data: {qr_data}")
                
                # Save QR code to database
                if insert_qr_code(qr_type, qr_data):
                    st.success("QR Code saved to database")
                
                # Add to scanned data list
                scanned_data.append({"Type": qr_type, "Data": qr_data})
                
                # Extract demand_id if present in QR code
                demand_id = None
                try:
                    if "Demand ID:" in qr_data:
                        demand_id_str = qr_data.split("Demand ID:")[1].split("\n")[0].strip()
                        demand_id = int(demand_id_str)
                except (IndexError, ValueError):
                    st.error("❌ Invalid QR Code Format")
                
                # Update demand status if ID was found
                if demand_id:
                    if update_demand_status(demand_id):
                        st.success(f"✅ Demand status for ID {demand_id} updated to 'Fulfilled'")
                    
                    # Send email notifications
                    emails = get_email_subscribers()
                    for email in emails:
                        if send_alert_email(email, demand_id):
                            st.info(f"Notification sent to {email}")
                
                # Handle URL in QR code
                if qr_data.startswith('http://') or qr_data.startswith('https://'):
                    st.markdown(f"[Open Link]({qr_data})")
                
                # Stop scanning after successful scan
                scanning = False
                break
            
            # Check for timeout
            if time.time() - scan_start_time > scan_duration:
                st.write("Scanning stopped due to timeout.")
                scanning = False
        
        # Show results table
        if scanned_data:
            st.subheader("Scanned QR Codes")
            df = pd.DataFrame(scanned_data)
            st.dataframe(df)
    
    # Release camera when done
    cam.release()