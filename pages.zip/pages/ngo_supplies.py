import streamlit as st
import pandas as pd
import qrcode
from io import BytesIO
import mysql.connector
import time
import os
from datetime import datetime

# Get database credentials from environment variables
mysql_user = os.getenv("MYSQL_USER")
mysql_password = os.getenv("MYSQL_PASSWORD")

def show(db):
    st.title("🏢 NGO Supply Management")
    if 'ngo_id' not in st.session_state:
        st.session_state.ngo_id = None
        st.session_state.ngo_name = None
    
    # Authentication section
    ngo_id = None
    
    # Get NGOs from database
    ngos = db.get_all_ngos()
    
    if ngos.empty:
        st.warning("⚠️ No NGOs found in the database.")
        return
    
    # Select NGO
    st.header("Login")
    selected_ngo = st.selectbox(
        "Select your NGO",
        options=ngos['ngo_id'].tolist(),
        format_func=lambda x: ngos[ngos['ngo_id'] == x]['name'].iloc[0],
        key="addintoinventory_ngo_selectbox"
    )
    password = st.text_input("Password", type="password", key="addintoinventory_password_input")
    
    # Login button
    if st.button("Login", key="addintoinventory_login_button"):
        if password:  # Simplified authentication
            st.session_state.ngo_id = selected_ngo
            st.session_state.ngo_name = ngos[ngos['ngo_id'] == selected_ngo]['name'].iloc[0]
            st.success(f"✅ Logged in as {st.session_state.ngo_name}")
        else:
            st.error("❌ Please enter a password")

    # Only show management interface if authenticated
    if st.session_state.ngo_id:
        st.markdown(f"### Welcome, {st.session_state.ngo_name}")
        st.markdown("---")
        
        # Quick metrics in columns
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Total Items", "1,234", "5%")
        col2.metric("Pending Deliveries", "45", "-2")
        col3.metric("Centers Served", "12", "1")
        col4.metric("Success Rate", "98%", "0.5%")
        
        st.markdown("---")
        
        # Main tabs
        tab1, tab4 = st.tabs([
            "📦 Inventory Management",
            "📊 Analytics"
        ])
        
        with tab1:
            col1, col2 = st.columns([2, 1])
            
            with col1:
                st.subheader("Current Inventory")
                conn = mysql.connector.connect(
                            host="localhost",
                            user=mysql_user,
                            password=mysql_password,
                            database="bantuannow",
                            port="3306"
                        )
                query = f"""
                SELECT ni.*, si.category 
                FROM ngo_inventory ni
                JOIN supply_items si ON ni.item_id = si.item_id
                WHERE ni.ngo_id = {st.session_state.ngo_id}
                """
                items = pd.read_sql_query(query, conn)
                conn.close()
                
                st.dataframe(
                    items,
                    hide_index=True,
                    use_container_width=True
                )

        with tab4:
            st.subheader("Supply Analytics")
            date_range = st.date_input(
                "Select Date Range",
                value=(datetime.now(), datetime.now()),
                key="analytics_date"
            )
            
            col1, col2 = st.columns(2)
            with col1:
                st.subheader("Items by Priority")
                priority_data = pd.DataFrame({
                    'Priority': ['Critical', 'High', 'Medium', 'Low'],
                    'Count': [10, 25, 45, 20]
                })
                st.bar_chart(priority_data.set_index('Priority'))
            
            with col2:
                st.subheader("Delivery Status")
                status_data = pd.DataFrame({
                    'Status': ['Pending', 'In Transit', 'Delivered'],
                    'Count': [15, 8, 77]
                })
                st.bar_chart(status_data.set_index('Status'))

