import streamlit as st
import mysql.connector
import os
import pandas as pd

# Get database credentials from environment variables
mysql_user = os.getenv("MYSQL_USER")
mysql_password = os.getenv("MYSQL_PASSWORD")

def login():
    st.title("NGO Login")
    
    # Get NGOs from database
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user=mysql_user,
            password=mysql_password,
            database="bantuannow",
            port="3306"
        )
        ngos = pd.read_sql_query("SELECT * FROM ngos2", conn)
        conn.close()
    except Exception as e:
        st.error(f"Database connection error: {e}")
        return None
    
    selected_ngo = st.selectbox(
        "Select your NGO",
        options=ngos['ngo_id'].tolist(),
        format_func=lambda x: ngos[ngos['ngo_id'] == x]['name'].iloc[0]
    )
    password = st.text_input("Password", type="password")
    
    if st.button("Login"):
        try:
            conn = mysql.connector.connect(
                host="localhost",
                user=mysql_user,
                password=mysql_password,
                database="bantuannow",
                port="3306"
            )
            cursor = conn.cursor()
            query = "SELECT * FROM ngos2 WHERE ngo_id = %s"
            cursor.execute(query, (selected_ngo,))
            result = cursor.fetchone()
            cursor.close()
            conn.close()
            
            if result and result['password_hash'] == password:  # Simplified password check
                st.success(f"✅ Logged in as {ngos[ngos['ngo_id'] == selected_ngo]['name'].iloc[0]}")
                st.session_state.ngo_id = selected_ngo
                st.experimental_set_query_params(rerun="true")
                return selected_ngo
            else:
                st.error("❌ Invalid credentials")
                return None
        except Exception as e:
            st.error(f"Database connection error: {e}")
            return None
    return None