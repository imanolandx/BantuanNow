# pages/alerts.py
import streamlit as st
import pandas as pd
import time
import mysql.connector 
import smtplib
import ssl
from datetime import datetime   
import os
from email.message import EmailMessage
import os
mysql_user = os.getenv("MYSQL_USER")
mysql_password = os.getenv("MYSQL_PASSWORD")
def show(db):
    st.title("Supply Alert System")
    
    # Get pending demands
    pending_demands = db.get_pending_demands()
    
    # Critical demands section
    st.subheader("Critical Demands")
    critical_demands = pending_demands[pending_demands['priority'] == 'Critical']
    
    if not critical_demands.empty:
        for _, demand in critical_demands.iterrows():
            with st.container(border=True):
                col1, col2 = st.columns([3, 1])
                
                with col1:
                    st.error(f"⚠️ URGENT: {demand['center_name']} needs {demand['quantity']} {demand['item_name']}")
                    st.write(f"Requested on: {demand['request_date']}")
                
    else:
        st.success("No critical demands at this time.")
    
    # All demands table
    st.subheader("All Pending Demands")
    
    if not pending_demands.empty:
        # Add color to priority
        def highlight_priority(val):
            colors = {
                'Critical': 'background-color: #54081e',
                'High': 'background-color: #E03C32',
                'Medium': 'background-color: #FFF215',
                'Low': 'background-color: #639754'
            }
            return colors.get(val, '')
        
        # Display styled table
        st.dataframe(
            pending_demands.style.applymap(
                highlight_priority, 
                subset=['priority']
            ),
            column_config={
                "demand_id": st.column_config.NumberColumn("ID"),
                "center_name": "Center",
                "item_name": "Item",
                "quantity": "Quantity",
                "priority": "Priority",
                "request_date": "Requested On"
            },
            use_container_width=True,
            hide_index=True
        )
    else:
        st.success("No pending demands at this time.")
    
    # Subscription section
    st.subheader("Alert Subscriptions")
    
    with st.form("alert_subscription"):
        email = st.text_input("Your Email")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("Select Priority Levels:")
            critical = st.checkbox("Critical", value=True)
            high = st.checkbox("High", value=True)
            medium = st.checkbox("Medium")
            low = st.checkbox("Low")
        
        with col2:
            st.write("Select Centers:")
            centers = db.get_all_centers()
            selected_centers = st.multiselect(
                "Centers to monitor",
                options=centers['center_id'].tolist(),
                format_func=lambda x: centers[centers['center_id'] == x]['name'].iloc[0]
            )
        
        subscribe = st.form_submit_button("Subscribe to Alerts")
        
        if subscribe and email:
            st.success("You've been subscribed to alerts!")
            st.info("You will receive email notifications for new demands matching your criteria.")
            try:
                conn = mysql.connector.connect(
                            host="localhost",
                            user=mysql_user,
                            password=mysql_password,
                            database="bantuannow",
                            port="3306"
                        )
                cursor = conn.cursor()
                # Insert query
                query = """
                INSERT INTO email_list_for_alerts (email, created_at) VALUES (%s, %s)
                """
                values = (email, datetime.now())
                cursor.execute(query, values)
                conn.commit()
                cursor.close()
                conn.close()
            except Exception as e:
                st.error(f"Failed to subscribe to alerts: {e}")
