# pages/tracking.py
import streamlit as st
import pandas as pd
import plotly.express as px

def show(db):
    st.title("Donation Tracking Dashboard")
    
    # Input email to track donations
    donor_email = st.text_input("Enter your email to track your donations:")
    
    if st.button("Track Donations") and donor_email:
        # Get donation data
        donations = db.track_donation(donor_email)
        
        if donations.empty:
            st.warning("No donations found for this email address.")
            return
        
        # Display donation summary
        st.subheader("Your Donations")
        
        # Group by NGO and sum amounts
        ngo_summary = donations.groupby('ngo_name')['amount'].sum().reset_index()
        
        # Create a pie chart
        fig = px.pie(
            ngo_summary,
            values='amount',
            names='ngo_name',
            title='Your Donations by Organization'
        )
        st.plotly_chart(fig)
        
        # Display detailed donation records
        st.subheader("Donation Details")
        
        # Group donations
        grouped_donations = donations.groupby(['donation_id', 'ngo_name', 'amount', 'donation_date'])
        
        for (donation_id, ngo_name, amount, date), group in grouped_donations:
            with st.expander(f"Donation #{donation_id}: ${amount:.2f} to {ngo_name} on {date.strftime('%Y-%m-%d')}"):
                # Calculate allocation percentage
                allocated = group['allocated_amount'].sum()
                
                # Progress bar for allocation
                allocation_percent = int((allocated / amount) * 100)
                st.write(f"Allocation Progress: {allocation_percent}%")
                st.progress(allocation_percent / 100)
                
                # Display allocations
                if not pd.isna(group['purpose']).all():
                    st.write("**Allocation Breakdown:**")
                    allocations = group[['purpose', 'allocated_amount', 'allocation_date']].dropna()
                    
                    for _, row in allocations.iterrows():
                        st.write(f"- ${row['allocated_amount']:.2f} for {row['purpose']} on {row['allocation_date'].strftime('%Y-%m-%d')}")
                else:
                    st.info("Your donation is still being allocated.")