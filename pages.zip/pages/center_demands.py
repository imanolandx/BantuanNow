import streamlit as st
from datetime import datetime
from database import Database  # Ensure you have the Database class implemented
import pandas as pd
import smtplib
import ssl
from datetime import datetime   
import os
from email.message import EmailMessage
import os
import mysql.connector
mysql_user = os.getenv("MYSQL_USER")
mysql_password = os.getenv("MYSQL_PASSWORD")
time = datetime.now()

def send_alert_email(email, demand_ngo, demand_item_id, demand_quantity, demand_priority, center_id, demand_id):
    try:
        email_sender = os.getenv('EMAIL_USER')
        email_password = os.getenv('EMAIL_PASSWORD')
        
        if not email_sender or not email_password:
            raise ValueError("Email credentials not found in environment variables")
        
        # Create the email message
        em = EmailMessage()
        em['From'] = email_sender
        em['To'] = email
        em['Subject'] = "New Supply Alert Notification"

        conn = mysql.connector.connect(
                    host="localhost",
                    user=mysql_user,
                    password=mysql_password,
                    database="bantuannow",
                    port="3306"
                )
        centers = pd.read_sql_query("SELECT * FROM flood_centers2", conn)
        supply_items = pd.read_sql_query("SELECT * FROM supply_items", conn)
        conn.close()
        
        # Check if center_id exists
        if center_id in centers['center_id'].values:
            center_name = centers.loc[centers['center_id'] == center_id, 'name'].values[0]
        else:
            center_name = "Unknown Center"

        # Check if demand_item_id exists
        if demand_item_id in supply_items['item_id'].values:
            item_name = supply_items.loc[supply_items['item_id'] == demand_item_id, 'name'].values[0]
        else:
            item_name = "Unknown Item"
        
        email_content = f"""
        Dear Subscriber,
        
        There are new supply demands that match your subscription criteria:
        
        Flood Center: {center_name}
        Item: {item_name}
        Demand ID: {demand_id}
        Item ID: {demand_item_id}
        Quantity: {demand_quantity}
        Priority: {demand_priority}
        NGO: {demand_ngo}
        
        Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}
        
        Best regards,
        Flood Monitoring Team
        """
        
        em.set_content(email_content)
        
        # Create SSL context
        context = ssl.create_default_context()
        
        # Send the email
        with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=context) as smtp:
            smtp.login(email_sender, email_password)
            smtp.sendmail(email_sender, email, em.as_string())
            
        return True
    except Exception as e:
        st.error(f"Failed to send email receipt: {str(e)}")
        return False


def show(db):
    st.title("Center Demands and Supplies")
    tab1, tab2 = st.tabs([
        "Inventory Management", "Request supply"
    ])
    with tab1:
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.subheader("Current Inventory")
            conn = mysql.connector.connect(
                        host="localhost",
                        user=mysql_user,
                        password=mysql_password,
                        database="bantuannow",
                        port="3306"
                    )
            query = f"""
            SELECT 
                n.name as NGO,
                si.name as Item,
                ni.quantity as Quantity,
                ni.expiry_date as 'Expiry Date',
                ni.source as Source,
                ni.notes as Notes,
                ni.last_updated as 'Last Updated'
            FROM ngo_inventory ni
            JOIN ngos2 n ON ni.ngo_id = n.ngo_id
            JOIN supply_items si ON ni.item_id = si.item_id
            """
            items = pd.read_sql_query(query, conn)
            conn.close()
            
            st.dataframe(
                items,
                hide_index=True,
                use_container_width=True
            )
    # Get flood centers and supply items from the database
    with tab2:
        centers = db.get_all_centers()
        supply_items = pd.read_sql_query("SELECT * FROM supply_items", db.conn)
        ngos = db.get_all_ngos()

        if centers.empty:
            st.warning("No flood centers found in the database.")
            return

        if supply_items.empty:
            st.warning("No supply items found in the database.")
            return

        # Select flood center
        center_id = st.selectbox(
            "Select Flood Center",
            options=centers['center_id'].tolist(),
            format_func=lambda x: centers[centers['center_id'] == x]['name'].iloc[0],
            key="center_selectbox"
        )
        
        # Form to enter demands
        st.subheader("Enter Demands")
        demand_ngo = st.selectbox(
            "Select NGO",
            options=ngos['name'].tolist(),
            format_func=lambda x: ngos[ngos['name'] == x]['name'].iloc[0],
            key="demand_ngos_selectbox"
        )
        demand_item_id = st.selectbox(
            "Select Item",
            options=supply_items['item_id'].tolist(),
            format_func=lambda x: supply_items[supply_items['item_id'] == x]['name'].iloc[0],
            key="demand_item_selectbox"
        )
        demand_quantity = st.number_input("Quantity", min_value=1, key="demand_quantity_input")
        demand_priority = st.selectbox("Priority", ["Low", "Medium", "High", "Critical"], key="demand_priority_selectbox")
        conn = mysql.connector.connect(
                        host="localhost",
                        user=mysql_user,
                        password=mysql_password,
                        database="bantuannow",
                        port="3306"
                    )
        email_df = pd.read_sql_query("SELECT email from email_list_for_alerts", conn)
        conn.close()
        if st.button("Submit Demand"):
            # Create demand and get the newly created demand_id
            demand_id = db.create_demand(center_id, demand_item_id, demand_quantity, demand_priority)
            st.success(f"Demand submitted successfully! Demand ID: {demand_id}")
            # Send alert emails to all subscribers
            for email in email_df['email']:
                send_alert_email(email, demand_ngo, demand_item_id, demand_quantity, demand_priority, center_id, demand_id)