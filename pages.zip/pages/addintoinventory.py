import streamlit as st
import pandas as pd
import mysql.connector
import os
from datetime import datetime

# Get database credentials from environment variables
mysql_user = os.getenv("MYSQL_USER")
mysql_password = os.getenv("MYSQL_PASSWORD")

def show(db):
    st.title("🏢 NGO Adding System")
    
    # Authentication section
    if 'ngo_id' not in st.session_state:
        st.session_state.ngo_id = None
        st.session_state.ngo_name = None
    
    # Get NGOs from the database
    ngos = db.get_all_ngos()
    
    if ngos.empty:
        st.warning("⚠️ No NGOs found in the database.")
        return
    
    # Select NGO
    st.header("Login")
    selected_ngo = st.selectbox(
        "Select your NGO",
        options=ngos['ngo_id'].tolist(),
        format_func=lambda x: ngos[ngos['ngo_id'] == x]['name'].iloc[0],
        key="addintoinventory_ngo_selectbox"
    )
    password = st.text_input("Password", type="password", key="addintoinventory_password_input")
    
    # Login button
    if st.button("Login", key="addintoinventory_login_button"):
        if password:  # Simplified authentication
            st.session_state.ngo_id = selected_ngo
            st.session_state.ngo_name = ngos[ngos['ngo_id'] == selected_ngo]['name'].iloc[0]
            st.success(f"✅ Logged in as {st.session_state.ngo_name}")
        else:
            st.error("❌ Please enter a password")
    
    # Only show the inventory management interface if authenticated
    if st.session_state.ngo_id:
        st.markdown(f"### Welcome, {st.session_state.ngo_name}")
        st.markdown("---")
        st.subheader("Add New Items")
        
        with st.form("add_supplies_form"):
            try:
                conn = mysql.connector.connect(
                    host="localhost",
                    user=mysql_user,
                    password=mysql_password,
                    database="bantuannow",
                    port="3306"
                )
                items = pd.read_sql_query("SELECT * FROM supply_items", conn)
                conn.close()
            except Exception as e:
                st.error(f"Database connection error: {e}")
                items = pd.DataFrame(columns=['item_id', 'name'])

            item_id = st.selectbox(
                "Item Type",
                options=items['item_id'].tolist(),
                format_func=lambda x: items[items['item_id'] == x]['name'].iloc[0],
                key="item_selectbox"
            )
            quantity = st.number_input("Quantity", min_value=1, value=10, key="quantity_input")
            batch_id = st.text_input("Batch ID", key="batch_id_input")
            expiry_date = st.date_input("Expiry Date", key="expiry_date_input")
            source = st.text_input("Source/Supplier", key="source_input")
            notes = st.text_area("Notes", key="notes_input")
            submitted = st.form_submit_button("Add to Inventory")
            
            if submitted:
                if all([item_id, quantity, expiry_date]):
                    try:
                        conn = mysql.connector.connect(
                            host="localhost",
                            user=mysql_user,
                            password=mysql_password,
                            database="bantuannow",
                            port="3306"
                        )
                        cursor = conn.cursor()
                        item_name = items[items['item_id'] == item_id]['name'].iloc[0]
                        # Insert query
                        query = """
                        INSERT INTO ngo_inventory (ngo_id, item_id, name, quantity, expiry_date, batch_id, source, notes, last_updated)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                        """
                        values = (st.session_state.ngo_id, item_id, item_name, quantity, expiry_date, batch_id, source, notes, datetime.now())
                        cursor.execute(query, values)
                        conn.commit()
                        cursor.close()
                        conn.close()

                        st.success("✅ Items added successfully!")
                    except Exception as e:
                        st.error(f"❌ Error: {str(e)}")
                else:
                    st.error("Please fill in all required fields")
