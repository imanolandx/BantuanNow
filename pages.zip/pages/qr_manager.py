import streamlit as st
import pandas as pd
import qrcode
from io import BytesIO
from PIL import Image
from datetime import datetime
import base64
from database import Database  # Import the Database class

def show(db):
    if 'ngo_id' not in st.session_state:
        st.session_state.ngo_id = None
        st.session_state.ngo_name = None
    
    ngos = db.get_all_ngos()
    
    if ngos.empty:
        st.warning("⚠️ No NGOs found in the database.")
        return
    
    st.header("Login")
    selected_ngo = st.selectbox(
        "Select your NGO",
        options=ngos['ngo_id'].tolist(),
        format_func=lambda x: ngos[ngos['ngo_id'] == x]['name'].iloc[0],
        key="addintoinventory_ngo_selectbox"
    )
    password = st.text_input("Password", type="password", key="addintoinventory_password_input")
    
    if st.button("Login", key="addintoinventory_login_button"):
        if password:
            st.session_state.ngo_id = selected_ngo
            st.session_state.ngo_name = ngos[ngos['ngo_id'] == selected_ngo]['name'].iloc[0]
            st.success(f"✅ Logged in as {st.session_state.ngo_name}")
        else:
            st.error("❌ Please enter a password")
    
    if st.session_state.ngo_id is None:
        return
    
    ngo_id = st.session_state.ngo_id
    st.title("QR Code Management")
    st.subheader("Create Supply Box QR Code")
    
    inventory_items = pd.read_sql_query("SELECT * FROM ngo_inventory WHERE ngo_id = %s", db.conn, params=(ngo_id,))
    centers = pd.read_sql_query("SELECT * FROM flood_centers2", db.conn)
    
    if inventory_items.empty:
        st.warning("No supply items available in the NGO inventory. Please add items first.")
        return
    
    if centers.empty:
        st.warning("No centers available. Please add centers first.")
        return
    
    st.write("Add items to the supply box:")
    box_id = st.text_input("Box ID: ")
    demand_id = st.text_input("Demand ID: ")  # New input field
    
    box_items = []
    for i in range(5):
        col1, col2 = st.columns(2)
        with col1:
            inventory_options = inventory_items[['inventory_id', 'source', 'name']].dropna()
            inventory_id = st.selectbox(
                f"Item {i+1}",
                options=inventory_options['inventory_id'].tolist(),
                format_func=lambda x: f"{inventory_options[inventory_options['inventory_id'] == x]['name'].iloc[0]} - {inventory_options[inventory_options['inventory_id'] == x]['source'].iloc[0]} (ID: {x})",
                key=f"item_{i}"
            )
        
        with col2:
            quantity = st.number_input(
                f"Quantity {i+1}", 
                min_value=0, 
                value=0,
                key=f"qty_{i}"
            )
        
        if inventory_id:
            box_items.append((inventory_id, quantity))
    
    destination = st.selectbox(
        "Select Destination Center",
        options=centers['center_id'].tolist(),
        format_func=lambda x: centers[centers['center_id'] == x]['name'].iloc[0],
        key="destination_selectbox"
    )
    priority = st.selectbox("Priority", ["Low", "Medium", "High", "Critical"])
    
    if st.button("Create Box"):
        if box_items and demand_id:
            box_id = db.get_next_box_id()
            
            db.cursor.execute(
                "INSERT INTO supply_boxes (box_id, created_date) VALUES (%s, %s)",
                (box_id, datetime.now())
            )
            db.conn.commit()

            for inventory_id, quantity in box_items:
                content_id = db.get_next_content_id()  
                db.add_item_to_box(content_id, box_id, inventory_id, quantity)
                db.cursor.execute(
                    "UPDATE ngo_inventory SET quantity = GREATEST(quantity - %s, 0) WHERE inventory_id = %s",
                    (quantity, inventory_id)
                )
            
            db.conn.commit()
            db.insert_box_ngo_info(box_id, destination, priority)
            
            qr_data = f"Box ID: {box_id}\nDemand ID: {demand_id}\nDestination: {centers[centers['center_id'] == destination]['name'].iloc[0]}\nPriority: {priority}\nItems:\n"
            for inventory_id, quantity in box_items:
                item_name = inventory_items[inventory_items['inventory_id'] == inventory_id]['name'].iloc[0]
                qr_data += f"- {item_name}: {quantity}\n"

            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(qr_data)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white")

            buffered = BytesIO()
            img.save(buffered, format="PNG")
            img_str = base64.b64encode(buffered.getvalue()).decode()

            st.success(f"Box ID: {box_id} created successfully! Inventory updated.")
            st.markdown(f'<img src="data:image/png;base64,{img_str}" width="300">', unsafe_allow_html=True)
            
            st.download_button(
                label="Download QR Code",
                data=buffered.getvalue(),
                file_name=f"box_{box_id}_qr.png",
                mime="image/png"
            )
