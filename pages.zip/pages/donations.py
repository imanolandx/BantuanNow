import streamlit as st
import pandas as pd
import smtplib
import ssl
from email.message import EmailMessage
import os
from datetime import datetime
def send_donation_receipt(donor_email, donor_name, amount, donation_id, ngo_name):
    try:
        email_sender = os.getenv('EMAIL_USER')
        email_password = os.getenv('EMAIL_PASSWORD')
        
        if not email_sender or not email_password:
            raise ValueError("Email credentials not found in environment variables")
        
        # Create the email message
        em = EmailMessage()
        em['From'] = email_sender
        em['To'] = donor_email
        em['Subject'] = f"Donation Receipt - {ngo_name}"
        
        # Email content
        email_content = f"""
        Dear {donor_name},
        
        Thank you for your generous donation to {ngo_name}!
        
        Donation Details:
        -----------------
        Amount: RM{amount:.2f}
        Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        Donation ID: {donation_id}
        
        Your contribution will help provide essential supplies and support to flood victims.
        You can track your donation using the Donation ID on our website.
        
        Thank you for making a difference!
        
        Best regards,
        Flood Relief Team
        """
        
        em.set_content(email_content)
        
        # Create SSL context
        context = ssl.create_default_context()
        
        # Send the email
        with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=context) as smtp:
            smtp.login(email_sender, email_password)
            smtp.sendmail(email_sender, donor_email, em.as_string())
            
        return True
    except Exception as e:
        st.error(f"Failed to send email receipt: {str(e)}")
        return False
def show(db):
    st.title("Donate to Flood Relief")
    
    # Get verified NGOs
    ngos = db.get_all_ngos()
    
    if ngos.empty:
        st.warning("No verified NGOs available for donation at this time.")
        return
    
    # NGO selection using dropdown
    st.subheader("Select an NGO to donate to:")
    
    # Create dropdown for NGO selection
    selected_ngo = st.selectbox(
        "Choose an NGO:",
        options=ngos['ngo_id'].tolist(),
        format_func=lambda x: ngos[ngos['ngo_id'] == x]['name'].iloc[0]
    )
    
    # Display selected NGO info
    if selected_ngo:
        ngo_info = ngos[ngos['ngo_id'] == selected_ngo].iloc[0]
        with st.container(border=True):
            st.write("**NGO Details:**")
            st.write(f"**Description:** {ngo_info['description']}")
            st.write(f"**Website:** [{ngo_info['website']}]({ngo_info['website']})")
        
        # Donation form
        st.subheader("Make a Donation")
        ngo_name = ngo_info['name']
        st.write(f"You are donating to: **{ngo_name}**")
        
        with st.form("donation_form"):
            col1, col2 = st.columns(2)
            with col1:
                donor_name = st.text_input("Your Name")
                donor_email = st.text_input("Your Email")
            with col2:
                amount = st.number_input("Donation Amount (RM)", min_value=5.0, step=5.0)
                payment_method = st.selectbox(
                    "Payment Method",
                    options=["Credit Card", "PayPal", "Bank Transfer"]
                )
            
            submit = st.form_submit_button("Complete Donation", use_container_width=True)
            
            if submit:
                if donor_name and donor_email and amount > 0:
                    try:
                        # Process donation
                        donation_id = db.create_donation(
                            selected_ngo, donor_name, donor_email, amount, payment_method
                        )
                        
                        # Send email receipt
                        if send_donation_receipt(donor_email, donor_name, amount, donation_id, ngo_name):
                            st.success(f"Thank you for your donation of RM{amount:.2f}!")
                            st.info(f"Donation ID: {donation_id}. A receipt has been sent to your email.")
                            st.write("Use the 'Donation Tracking' page to see how your donation is being used.")
                        else:
                            st.warning("Donation successful but failed to send email receipt.")
                            st.info(f"Please save your Donation ID: {donation_id}")
                            
                    except Exception as e:
                        st.error(f"Failed to process donation: {e}")
                else:
                    st.error("Please fill in all fields with valid information.")
    
    # Information about donation use
    st.markdown("---")
    st.subheader("How Your Donation Helps")
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("""
        Your generous donations directly support flood victims by providing:
        - Emergency food supplies 🥫
        - Clean drinking water 💧
        - Medical supplies and care 🏥
        """)
    
    with col2:
        st.write("""
        Additional support includes:
        - Temporary shelter 🏠
        - Evacuation assistance 🚌
        - Long-term rehabilitation 🔄
        """)
    
    st.info(
        "2% of the donations will be donated to maintain the system."
        " All donations are tracked through our transparent system, allowing you to see "
        "exactly how your contribution is making a difference.", 
        icon="ℹ️"
    )