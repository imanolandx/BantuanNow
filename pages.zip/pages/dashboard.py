import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

def show(db):
    st.title("Flood Center Supply Dashboard")
    
    # Get all centers
    centers = db.get_all_centers()
    
    #st.dataframe(centers)
    # Layout with columns
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.subheader("Flood Centers")
        # Display full centers table
        
        
        # Add filter for center_id without default selection
        center_filter = st.multiselect(
            "Filter by center:",
            options=centers['center_id'].tolist(),
            format_func=lambda x: centers[centers['center_id'] == x]['name'].iloc[0]
        )
        
        # If filters are selected, show filtered view
        if center_filter:
            centers = centers[centers['center_id'].isin(center_filter)]
        st.dataframe(centers)
        
        # Display center info
        
    
    with col2:
        st.subheader("Supply Demands")
        selected_center = st.selectbox(
            "Select a center to view details:",
            options=centers['center_id'].tolist(),
            format_func=lambda x: centers[centers['center_id'] == x]['name'].iloc[0]
        )
        
        # Get demands for selected center
        demands = db.get_center_demands(selected_center)
        
        if not demands.empty:
            # Create a status filter
            status_filter = st.multiselect(
                "Filter by status:",
                options=demands['status'].unique(),
                default=demands['status'].unique()
            )
            
            filtered_demands = demands[demands['status'].isin(status_filter)]
            
            # Display demands as a styled table
            st.dataframe(
                filtered_demands,
                column_config={
                    "demand_id": "ID",
                    "name": "Item",
                    "quantity": "Quantity",
                    "priority": st.column_config.SelectboxColumn(
                        "Priority",
                        help="Supply priority",
                        width="medium",
                        options=["Critical", "High", "Medium", "Low"]
                    ),
                    "status": st.column_config.SelectboxColumn(
                        "Status",
                        width="medium",
                        options=["Pending", "In Progress", "Fulfilled", "Cancelled"]
                    ),
                    "request_date": "Requested On"
                },
                use_container_width=True,
                hide_index=True,
                height=400
            )
        else:
            st.info("No demands found for this center.")
    
    # Analytics section
    st.subheader("Supply Analytics")
    
    # Get all pending demands for analytics
    all_demands = db.get_pending_demands()
    
    if not all_demands.empty:
        col1, col2 = st.columns(2)
        
        with col1:
            # Demands by priority
            priority_counts = all_demands['priority'].value_counts().reset_index()
            priority_counts.columns = ['Priority', 'Count']
            
            fig = px.pie(
                priority_counts, 
                values='Count', 
                names='Priority',
                title='Demands by Priority',
                color='Priority',
                color_discrete_map={
                    'Critical': 'red',
                    'High': 'orange',
                    'Medium': 'yellow',
                    'Low': 'green'
                }
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Demands by center
            center_counts = all_demands['center_name'].value_counts().reset_index()
            center_counts.columns = ['Center', 'Count']
            
            fig = px.bar(
                center_counts,
                x='Center',
                y='Count',
                title='Demands by Center',
                color='Count',
                color_continuous_scale='Blues'
            )
            st.plotly_chart(fig, use_container_width=True)